'''
Created on Apr 19, 2015
@author: Brian Borowski

CS115 - Client (driver) program for Shapes
'''
from circle import Circle
from square import Square
from rectangle import Rectangle
from triangle import Triangle

if __name__ == '__main__':
    list_of_shapes = []
    while True:
        print 'Enter the type of shape you wish to create:'
        print '   [C]ircle'
        print '   [T]riangle'
        print '   [R]ectangle'
        print '   [S]quare'
        print '   [Q]uit'
        choice = raw_input('? ').strip().lower()
        if not choice in 'ctrsq':
            continue
        if choice == 'q':
            break
        x = int(raw_input('Enter x-coordinate: ').strip())
        y = int(raw_input('Enter y-coordinate: ').strip())
        if choice == 'c':
            radius = float(raw_input('Enter radius: ').strip())
            shape = Circle(x, y, radius)
        elif choice == 't':
            base = float(raw_input('Enter base: ').strip())
            height = float(raw_input('Enter height: ').strip())
            shape = Triangle(x, y, base, height)
        elif choice == 'r':
            length = float(raw_input('Enter length: ').strip())
            width = float(raw_input('Enter width: ').strip())
            shape = Rectangle(x, y, length, width)
        else:
            sidelength = float(raw_input('Enter side length: ').strip())
            shape = Square(x, y, sidelength)
        list_of_shapes.append(shape)
    for shape in list_of_shapes:
        print shape
