# @PydevCodeAnalysisIgnore
'''
Created on Apr 19, 2015
@author: Brian Borowski

CS115 - Square class
'''
from rectangle import Rectangle

class Square(Rectangle):
    def __init__(self, x, y, length, name='Square'):
        Rectangle.__init__(self, x, y, length, length, name)

    @property
    def length(self):
        return super(Square, self).length

    @length.setter
    def length(self, length):
        Rectangle.length.fset(self, length)
        Rectangle.width.fset(self, length)

    @property
    def width(self):
        return super(Square, self).width

    @width.setter
    def width(self, width):
        Rectangle.length.fset(self, width)
        Rectangle.width.fset(self, width)

if __name__ == '__main__':
    sqr = Square(10, 10, 20)
    print 'Square length:', sqr.length
    print 'Square width:', sqr.width
    sqr.length = 50
    print 'Square length:', sqr.length
    print 'Square width:', sqr.width
    print sqr
    sqr.length = 40
    print 'Square length:', sqr.length
    print 'Square width:', sqr.width
    sqr.width = 100
    print sqr
